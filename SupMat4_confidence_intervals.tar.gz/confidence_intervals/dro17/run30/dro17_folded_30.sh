#!/bin/bash
#BSUB -L /bin/bash
#BSUB -o run30-%J-error.txt
#BSUB -e run30-%J-output.txt
#BSUB -J dro17_foldedrun30
#BSUB -R rusage[mem=32768]
#BSUB -M 33554432
chmod u+x fsc25221
./fsc25221 -t dro17_folded.tpl -e dro17_folded.est -m -n 100000 -N 100000 -M 0.01 -l 10 -L 40 -q -c 1 -B 1 -x --multiSFS
rm ./fsc25221
