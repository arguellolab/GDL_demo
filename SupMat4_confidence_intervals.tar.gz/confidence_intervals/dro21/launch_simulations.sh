
#Remember current directory
current_dir=`pwd`
#Define version of the software
fsc="fsc25221"
#Define PAR file
parFile="dro21_folded_maxL.par"
#Define number of replicates
n_rep=67


#BSUB -q multicore40
#BSUB -o out.txt
#BSUB -e err.txt
#BSUB -n 40
#BSUB -R "rusage[mem=16384]"
#BSUB -M 16777216


$fsc -i $parFile -n $n_rep -I -s 0 -m -x -q -D -k 200000 -u -c 40 -B 40


