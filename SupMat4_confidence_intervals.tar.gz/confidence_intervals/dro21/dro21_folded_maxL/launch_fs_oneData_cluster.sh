
# Stefan Laurent (Modified from L. Excoffier)	November 2014
# This script was written to organize the launching of fastsimcoal2 on the VITAL-IT cluster at EPFL
#
#
#
# It assumes the following structure of input files
#
# 	script_directory
#	   |
#	   |---*.tpl
#	   |---*.est
#	   |---fsc
#	   |---dirWithObsData
#		   |
#		   |---*.obs
#################################################################################################################

set -x;

#Making sure that I have a folder in the vital-it scratch directory
#mkdir /netscratch/dep_tsiantis/grp_laurent/private/ 1> /dev/null 2>&1;

fsc=fsc25221;
numOfThreads=1;
jobcount=0;
workDir=`pwd`

#---Number of runs per dataset ---#
numRuns=50;
runBase=1;
#---------------------------------#


#---Default run values-------------------------------------------#
iniNumSims=100000;			# -n command line option default(100000) #
maxNumSims=100000;			# -N command line option default(100000) #
minNumCycles=10;			# -l command line option #
maxNumCycles=40;			# -L command line option default(40) #
stopCrit=0.01;				# -M command line option #
minValidSFSEntry=1;			# -C command line option #
#----------------------------------------------------------------#

#---Generic name-------------------------------------------------#
genericName=dro21_folded;
tplGenericName=dro21_folded;
estGenericName=dro21_folded;

#----------------------------------------------------------------#

#preparing scratch directory for launching
#rm -r /scratch/cluster/monthly/puffel/fsc 1> /dev/null 2>&1;
mkdir /netscratch/dep_tsiantis/grp_laurent/private/$1 1> /dev/null 2>&1;
cd /netscratch/dep_tsiantis/grp_laurent/private/$1;
cp -r $workDir/$1 . ;
cd $1;

#For every observed dataset
for dirs in `ls`
do
	#check that dir is a directory
	if [ -d "$dirs" ]
	then

		cd $dirs

		echo $dirs;

		tplFile=$tplGenericName.tpl;
		estFile=$estGenericName.est;

		for ((runsDone=$runBase; runsDone<=$numRuns; runsDone++ ))

		do

			runDir=run$runsDone;
			mkdir $runDir;
			cd $runDir;
			#cp ../../$fsc .;
			cp ../../$tplFile .;
			cp ../../$estFile .;
			cp ../*.obs .;

			jobCount=$(($jobCount+1));
			jobName=${genericName}_${jobCount}.sh;
			#Creating the bash file on the fly
			(
			echo "#!/bin/bash"
			echo "#BSUB -L /bin/bash"
			echo "#BSUB -e $runDir-%J-error.txt"
			echo "#BSUB -o $runDir-%J-output.txt"
			echo "#BSUB -J $genericName$runDir"				#Job name
			#echo "#BSUB -n $numOfThreads "					#Specifies the number of cores
			#echo "#BSUB -R "span[ptile=$numOfThreads]""			#num of cores on the same host
			echo "#BSUB -R "rusage[mem=50]""				#num of cores on the same host
			echo "#BSUB -M 51200"					#num of cores on the same host
			#echo "chmod u+x $fsc";
			echo "$fsc -t $tplFile -e $estFile -m -n $iniNumSims -N $maxNumSims -M $stopCrit -l $minNumCycles -L $maxNumCycles -q -c $numOfThreads -B $numOfThreads -x --multiSFS"
			#echo "rm ./$fsc"
			) > $jobName

			chmod u+x $jobName;
			bsub < ./$jobName;
			
			cd ../;
		done

		cd ../;

	fi

done
