#!/bin/bash
#BSUB -L /bin/bash
#BSUB -e run11-%J-error.txt
#BSUB -o run11-%J-output.txt
#BSUB -J dro21_foldedrun11
#BSUB -R rusage[mem=32768]
#BSUB -M 33554432
fsc25221 -t dro21_folded.tpl -e dro21_folded.est -m -n 100000 -N 100000 -M 0.01 -l 10 -L 40 -q -c 1 -B 1 -x --multiSFS
