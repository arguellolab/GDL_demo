#!/bin/bash
#BSUB -L /bin/bash
#BSUB -e run38-%J-error.txt
#BSUB -o run38-%J-output.txt
#BSUB -J NIZ03_foldedrun38
#BSUB -R rusage[mem=32768]
#BSUB -M 33554432
fsc25221 -t NIZ03_folded.tpl -e NIZ03_folded.est -m -n 100000 -N 100000 -M 0.01 -l 10 -L 40 -q -c 1 -B 1 -x --multiSFS
