set -x

mkdir temp
i=1;

split -l $1 $2;
mv x* temp

for file in `ls temp`

do

mkdir input_reEst/obs$i;
mv temp/$file input_reEst/obs$i/NIZ03_folded_MSFS.obs;

#add header and clean up
cat header input_reEst/obs$i/NIZ03_folded_MSFS.obs > input_reEst/obs$i/temp2
mv input_reEst/obs$i/temp2 input_reEst/obs$i/NIZ03_folded_MSFS.obs

i=`expr $i + 1`;

done

rm -r temp


