
#Remember current directory
current_dir=`pwd`
#Define version of the software
fsc="fsc25221"
#Define PAR file
parFile="dro25_folded_maxL.par"
#Define number of replicates
n_rep=100


#BSUB -q multicore20
#BSUB -o out.txt
#BSUB -e err.txt
#BSUB -n 20
#BSUB -R "rusage[mem=1024]"
#BSUB -M 1024


$fsc -i $parFile -n $n_rep -I -s 0 -m -x -q -D -k 200000 -u -c 40 -B 40


