#!/bin/bash
#BSUB -L /bin/bash
#BSUB -e run40-%J-error.txt
#BSUB -o run40-%J-output.txt
#BSUB -J dro25_foldedrun40
#BSUB -R rusage[mem=4096]
#BSUB -M 4096
fsc25221 -t dro25_folded.tpl -e dro25_folded.est -m -n 100000 -N 100000 -M 0.01 -l 10 -L 40 -q -c 1 -B 1 -x --multiSFS
